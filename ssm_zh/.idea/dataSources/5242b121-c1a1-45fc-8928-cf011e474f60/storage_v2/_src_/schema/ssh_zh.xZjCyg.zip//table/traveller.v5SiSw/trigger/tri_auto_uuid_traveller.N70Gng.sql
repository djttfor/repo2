create definer = root@`%` trigger tri_auto_uuid_traveller
  before INSERT
  on traveller
  for each row
BEGIN
  if NEW.id is null or new.id = '' then
    set NEW.id = substr(upper(replace(uuid(),'-','')),1,32);
  end if;
END;

