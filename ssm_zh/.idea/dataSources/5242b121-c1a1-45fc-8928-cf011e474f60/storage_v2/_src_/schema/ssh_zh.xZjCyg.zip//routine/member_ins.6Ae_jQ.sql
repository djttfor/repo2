create
    definer = root@`%` function member_ins(count int) returns int
begin
   declare i int;
   set i = 0;
   while i<count do
   insert into member(name,nick_name,phone_number,email)
   values (concat('张三',i),concat('呵呵',i),concat('1367784654',i),concat('123',i,'@qq.com'));
     set i= i+1;
   end while ;
   return 1;
end;

