create definer = root@`%` trigger tri_auto_uuid_role
    before insert
    on role
    for each row
BEGIN
  if NEW.id is null or new.id = '' then
    set NEW.id = substr(upper(replace(md5(uuid()),'-','')),1,32);
  end if;
END;

