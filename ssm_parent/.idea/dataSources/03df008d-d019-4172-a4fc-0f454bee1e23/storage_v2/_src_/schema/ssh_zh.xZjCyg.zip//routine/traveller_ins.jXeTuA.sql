create
  definer = root@`%` procedure traveller_ins(IN c int)
begin
  declare i int;
  set i = 0;
  while i< c do
  insert into traveller(name, sex, phone_number, credentials_type, credentials_number, traveller_type)
  values (concat('赵六',i),'女',concat('1397654123',i),0,'46789654231',0);
  end while ;

end;

